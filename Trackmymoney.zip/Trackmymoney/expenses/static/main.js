// script.js

console.log("Custom JS code loaded!");

// Add an event listener to the add category button
document.querySelector("#add-category-btn").addEventListener("click", function() {
  console.log("Add category button clicked!");
});

// Add an event listener to the add expense button
document.querySelector("#add-expense-btn").addEventListener("click", function() {
  console.log("Add expense button clicked!");
});