from django.urls import path
from . import views



urlpatterns = [
    path('', views.home, name='home'),
    path('add_category/', views.add_category, name='add_category'),
    path('add_expense/', views.add_expense, name='add_expense'),
    path('delete_category/<pk>/', views.delete_category, name='delete_category'),
    path('delete_expense/<pk>/', views.delete_expense, name='delete_expense'),  # Verify this line
]