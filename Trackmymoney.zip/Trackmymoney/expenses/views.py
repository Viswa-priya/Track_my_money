

# Create your views here.
# views.py
from django.shortcuts import render, redirect

from .models import Category, Expense
from .forms import CategoryForm, ExpenseForm

def home(request):
    categories = Category.objects.all()
    expenses = Expense.objects.all()
    return render(request, 'home.html', {'categories': categories, 'expenses': expenses})

def add_category(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = CategoryForm()
    return render(request, 'add_category.html', {'form': form})

def add_expense(request):
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = ExpenseForm()
    return render(request, 'add_expense.html', {'form': form})

#delete

def delete_category(request, pk):
    category = Category.objects.get(pk=pk)
    category.delete()
    return redirect('home')

def delete_expense(request, pk):
    expense = Expense.objects.get(pk=pk)
    expense.delete()
    return redirect('home')




